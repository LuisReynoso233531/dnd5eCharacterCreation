import 'dart:convert';
import 'dart:io';

import 'package:path_provider/path_provider.dart';

import '../../view_models/character/character_detail_class_view_model.dart';
import '../../view_models/character/character_inventory_view_model.dart';
import '../../view_models/character/character_spell_view_model.dart';
import '../../view_models/character/character_subclass_view_model.dart';
import '../../view_models/character/character_view_model.dart';
import '../models/saved_character_state.dart';

class CharacterProgressionStorage {
  static const String _folderName = 'character_data';

  // ─────────────────────────────────────────────────────────────
  // Directorios
  // ─────────────────────────────────────────────────────────────

  static Future<Directory> charactersDirectory() async {
    final baseDirectory =
        await getApplicationDocumentsDirectory();

    final directory = Directory(
      '${baseDirectory.path}/$_folderName',
    );

    if (!await directory.exists()) {
      await directory.create(recursive: true);
    }

    return directory;
  }

  static Future<Directory> characterVersionsDirectory(
    String characterId,
  ) async {
    final directory = await charactersDirectory();

    final versionsDirectory = Directory(
      '${directory.path}/'
      '${_safeId(characterId)}_versions',
    );

    if (!await versionsDirectory.exists()) {
      await versionsDirectory.create(
        recursive: true,
      );
    }

    return versionsDirectory;
  }

  // ─────────────────────────────────────────────────────────────
  // Personajes actuales
  // ─────────────────────────────────────────────────────────────

  static Future<List<SavedCharacterState>>
      listCharacters() async {
    final directory = await charactersDirectory();

    final files = await directory
        .list()
        .where(
          (entity) =>
              entity is File &&
              entity.path.endsWith('.json'),
        )
        .cast<File>()
        .toList();

    final characters = <SavedCharacterState>[];

    for (final file in files) {
      try {
        final raw = await file.readAsString();
        final decoded = jsonDecode(raw);

        if (decoded is! Map) {
          continue;
        }

        characters.add(
          SavedCharacterState.fromJson(
            Map<String, dynamic>.from(decoded),
          ),
        );
      } catch (_) {
        /*
         * Un archivo dañado no debe impedir que se
         * carguen los demás personajes.
         */
      }
    }

    characters.sort(
      (first, second) =>
          second.updatedAt.compareTo(first.updatedAt),
    );

    return characters;
  }

  static Future<SavedCharacterState?> loadCharacter(
    String id,
  ) async {
    if (id.trim().isEmpty) {
      return null;
    }

    final directory = await charactersDirectory();

    final file = File(
      '${directory.path}/${_safeId(id)}.json',
    );

    if (!await file.exists()) {
      return null;
    }

    try {
      final decoded = jsonDecode(
        await file.readAsString(),
      );

      if (decoded is! Map) {
        return null;
      }

      return SavedCharacterState.fromJson(
        Map<String, dynamic>.from(decoded),
      );
    } catch (_) {
      return null;
    }
  }

  static Future<SavedCharacterState?>
      findByCurrentPdfPath(
    String pdfPath,
  ) async {
    final characters = await listCharacters();

    for (final character in characters) {
      if (character.currentPdfPath == pdfPath) {
        return character;
      }
    }

    return null;
  }

  // ─────────────────────────────────────────────────────────────
  // Snapshots históricos
  // ─────────────────────────────────────────────────────────────

  static Future<List<CharacterStateSnapshot>>
      listSnapshots(
    String characterId,
  ) async {
    if (characterId.trim().isEmpty) {
      return const [];
    }

    final versionsDirectory =
        await characterVersionsDirectory(
      characterId,
    );

    final files = await versionsDirectory
        .list()
        .where(
          (entity) =>
              entity is File &&
              entity.path.endsWith('.json'),
        )
        .cast<File>()
        .toList();

    final snapshots = <CharacterStateSnapshot>[];

    for (final file in files) {
      try {
        final decoded = jsonDecode(
          await file.readAsString(),
        );

        if (decoded is! Map) {
          continue;
        }

        final state = SavedCharacterState.fromJson(
          Map<String, dynamic>.from(decoded),
        );

        snapshots.add(
          CharacterStateSnapshot(
            path: file.path,
            state: state,
          ),
        );
      } catch (_) {
        /*
         * Ignora únicamente el snapshot dañado.
         */
      }
    }

    snapshots.sort((first, second) {
      final levelComparison =
          second.state.level.compareTo(
        first.state.level,
      );

      if (levelComparison != 0) {
        return levelComparison;
      }

      return second.state.updatedAt.compareTo(
        first.state.updatedAt,
      );
    });

    return snapshots;
  }

  static Future<SavedCharacterState?> loadSnapshot(
    String snapshotPath,
  ) async {
    if (snapshotPath.trim().isEmpty) {
      return null;
    }

    final file = File(snapshotPath);

    if (!await file.exists()) {
      return null;
    }

    try {
      final decoded = jsonDecode(
        await file.readAsString(),
      );

      if (decoded is! Map) {
        return null;
      }

      return SavedCharacterState.fromJson(
        Map<String, dynamic>.from(decoded),
      );
    } catch (_) {
      return null;
    }
  }

  // ─────────────────────────────────────────────────────────────
  // Guardado del personaje
  // ─────────────────────────────────────────────────────────────

  static Future<SavedCharacterState>
      saveGeneratedCharacter({
    required CreateCharacterViewModel vm,
    required CharacterInventoryViewModel inventoryVM,
    required String pdfPath,
    DetailClassViewModel? detailVM,
    CharacterSubclassViewModel? subclassVM,
    CharacterSpellViewModel? spellVM,
    String playerName = '',
    String alignment = '',
    String temporaryHp = '',
    String personalityTraits = '',
    String ideals = '',
    String bonds = '',
    String flaws = '',
  }) async {
    final selectedClass = vm.selectedClass;
    final selectedRace = vm.selectedRace;

    if (selectedClass == null ||
        selectedRace == null) {
      throw StateError(
        'A race and class are required before '
        'saving character progression.',
      );
    }

    final now = DateTime.now();
    final existingId = vm.editingCharacterId;

    final existing = existingId == null
        ? null
        : await loadCharacter(existingId);

    final id = existing?.id ??
        existingId ??
        '${_safeId(vm.name)}_'
            '${now.microsecondsSinceEpoch}';

    final history = <CharacterPdfVersion>[
      ...?existing?.pdfHistory,
    ];

    if (!history.any(
      (version) => version.path == pdfPath,
    )) {
      history.add(
        CharacterPdfVersion(
          level: vm.level,
          path: pdfPath,
          createdAt: now,
        ),
      );
    }

    history.sort((first, second) {
      final levelComparison =
          first.level.compareTo(second.level);

      if (levelComparison != 0) {
        return levelComparison;
      }

      return first.createdAt.compareTo(
        second.createdAt,
      );
    });

    final state = SavedCharacterState(
      id: id,
      name: vm.name,
      level: vm.level,
      raceData: Map<String, dynamic>.from(
        selectedRace,
      ),
      classData: Map<String, dynamic>.from(
        selectedClass.toJson(),
      ),
      backgroundData:
          vm.selectedBackground == null
              ? <String, dynamic>{}
              : Map<String, dynamic>.from(
                  vm.selectedBackground!,
                ),
      baseStats: Map<String, int>.from(
        vm.baseStats,
      ),
      levelUpChoices: {
        for (final entry
            in vm.levelUpChoices.entries)
          entry.key:
              Map<String, dynamic>.from(
            entry.value,
          ),
      },
      featChoices: {
        for (final entry
            in vm.featChoices.entries)
          entry.key: SavedFeatChoice(
            chosenStat:
                entry.value.chosenStat,
            proficiencies:
                List<String>.from(
              entry.value.proficiencies,
            ),
            languages:
                List<String>.from(
              entry.value.languages,
            ),
          ),
      },
      selectedDwarvenToolProficiency:
          vm.selectedDwarvenToolProficiency,
      selectedDraconicAncestry:
          vm.selectedDraconicAncestry == null
              ? null
              : Map<String, String>.from(
                  vm.selectedDraconicAncestry!,
                ),
      selectedClassSkills:
          List<String>.from(
        vm.skillVM.selectedClassSkills,
      ),
      selectedExpertise:
          List<String>.from(
        vm.skillVM.selectedExpertise,
      ),
      selectedRacialLanguages:
          List<String>.from(
        vm.languageVM.selectedRacialLanguages,
      ),
      selectedBackgroundLanguages:
          List<String>.from(
        vm.languageVM.selectedBgLanguages,
      ),
      selectedFeatLanguages:
          List<String>.from(
        vm.languageVM.selectedFeatLanguages,
      ),
      selectedEquipmentPackageIndex:
          vm.equipmentVM.selectedPackageIndex,
      hpRolls: detailVM == null
          ? Map<int, int>.from(
              existing?.hpRolls ??
                  const <int, int>{},
            )
          : Map<int, int>.from(
              detailVM.hpRolls,
            ),
      selectedArchetype:
          detailVM?.selectedArchetype == null
              ? existing?.selectedArchetype
              : Map<String, dynamic>.from(
                  detailVM!.selectedArchetype!,
                ),
      selectedFightingStyle:
          detailVM?.selectedFightingStyle == null
              ? existing?.selectedFightingStyle
              : Map<String, String>.from(
                  detailVM!
                      .selectedFightingStyle!,
                ),
      selectedFightingStyleName:
          detailVM
                  ?.selectedFightingStyleName ??
              existing
                  ?.selectedFightingStyleName,
      selectedBonusSkills:
          subclassVM == null
              ? List<String>.from(
                  existing
                          ?.selectedBonusSkills ??
                      const <String>[],
                )
              : List<String>.from(
                  subclassVM
                      .selectedBonusSkills,
                ),
      selectedSpellTableId:
          subclassVM?.selectedSpellTableId ??
              existing?.selectedSpellTableId,
      selectedSpells: spellVM == null
          ? {
              for (final entry in (
                existing?.selectedSpells ??
                    const {},
              ).entries)
                entry.key:
                    List<String>.from(
                  entry.value,
                ),
            }
          : {
              for (final entry in spellVM
                  .selectedSpells.entries)
                entry.key:
                    List<String>.from(
                  entry.value,
                ),
            },
      equippedArmorSlug:
          inventoryVM.equippedArmor?.slug,
      equippedShieldSlug:
          inventoryVM.equippedShield?.slug,
      weaponQuantities: {
        for (final entry
            in inventoryVM.weaponEntries)
          entry.weapon.slug: entry.quantity,
      },
      tools: List<String>.from(
        inventoryVM.tools,
      ),
      money: {
        'gp': inventoryVM.gp,
        'pp': inventoryVM.pp,
        'ep': inventoryVM.ep,
        'sp': inventoryVM.sp,
        'cp': inventoryVM.cp,
      },
      treasuresText:
          inventoryVM.treasuresText,
      playerName: playerName,
      alignment: alignment,
      temporaryHp: temporaryHp,
      personalityTraits: personalityTraits,
      ideals: ideals,
      bonds: bonds,
      flaws: flaws,
      currentPdfPath: pdfPath,
      pdfHistory: history,
      createdAt: existing?.createdAt ?? now,
      updatedAt: now,
    );

    /*
     * existing representa el personaje antes de la
     * modificación. _writeState decidirá si necesita
     * conservarlo como snapshot.
     */
    await _writeState(
      state,
      previousState: existing,
    );

    return state;
  }

  // ─────────────────────────────────────────────────────────────
  // Eliminación
  // ─────────────────────────────────────────────────────────────

  static Future<void> deleteCharacterData(
    String id,
  ) async {
    if (id.trim().isEmpty) {
      return;
    }

    final directory = await charactersDirectory();

    final currentFile = File(
      '${directory.path}/${_safeId(id)}.json',
    );

    if (await currentFile.exists()) {
      await currentFile.delete();
    }

    final versionsDirectory = Directory(
      '${directory.path}/'
      '${_safeId(id)}_versions',
    );

    if (await versionsDirectory.exists()) {
      await versionsDirectory.delete(
        recursive: true,
      );
    }
  }

  // ─────────────────────────────────────────────────────────────
  // Escritura interna
  // ─────────────────────────────────────────────────────────────

  static Future<void> _writeState(
    SavedCharacterState state, {
    SavedCharacterState? previousState,
  }) async {
    /*
     * Se crea el snapshot solo cuando realmente existe
     * una progresión de nivel.
     *
     * Guardar un PDF nuevamente en el mismo nivel no
     * genera copias JSON innecesarias.
     */
    if (previousState != null &&
        previousState.level != state.level) {
      await _writeVersionSnapshot(
        previousState,
      );
    }

    final directory = await charactersDirectory();

    final file = File(
      '${directory.path}/'
      '${_safeId(state.id)}.json',
    );

    final temporary = File(
      '${file.path}.tmp',
    );

    const encoder = JsonEncoder.withIndent('  ');

    await temporary.writeAsString(
      encoder.convert(state.toJson()),
      flush: true,
    );

    if (await file.exists()) {
      await file.delete();
    }

    await temporary.rename(file.path);
  }

  static Future<String> _writeVersionSnapshot(
    SavedCharacterState state,
  ) async {
    final versionsDirectory =
        await characterVersionsDirectory(
      state.id,
    );

    /*
     * Se usa updatedAt del estado anterior para obtener
     * un nombre estable. Si se reintenta la misma
     * operación, no se generan snapshots duplicados.
     */
    final versionId =
        'level_${state.level}_'
        '${state.updatedAt
            .toUtc()
            .microsecondsSinceEpoch}';

    final file = File(
      '${versionsDirectory.path}/'
      '$versionId.json',
    );

    if (await file.exists()) {
      return file.path;
    }

    final temporary = File(
      '${file.path}.tmp',
    );

    const encoder = JsonEncoder.withIndent('  ');

    await temporary.writeAsString(
      encoder.convert(state.toJson()),
      flush: true,
    );

    await temporary.rename(file.path);

    return file.path;
  }

  static String _safeId(String value) {
    final cleaned = value
        .trim()
        .replaceAll(
          RegExp(r'[^a-zA-Z0-9_\-]'),
          '_',
        )
        .replaceAll(
          RegExp(r'_+'),
          '_',
        );

    return cleaned.isEmpty
        ? 'character'
        : cleaned;
  }
}
  

class CharacterStateSnapshot {
  const CharacterStateSnapshot({
    required this.path,
    required this.state,
  });

  final String path;
  final SavedCharacterState state;

  int get level => state.level;

  DateTime get createdAt => state.updatedAt;

  String get pdfPath => state.currentPdfPath;
}
  
  